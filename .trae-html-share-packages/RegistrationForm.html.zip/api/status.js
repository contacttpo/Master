// Open  /api/status  to see if everything is connected.
// Open  /api/status?compare=1  to run each rewritten function on BOTH Google Sheets (new) and
// Apps Script (old), check the answers are identical, and see how long each took.
const google = require('../lib/google');
const ported = require('../lib/ported');
const { toObjects } = require('../lib/google');

function stable(v) {
  if (Array.isArray(v)) return '[' + v.map(stable).join(',') + ']';
  if (v && typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
function firstDiffs(a, b) {
  const out = [];
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) out.push('length differs: new=' + a.length + ' old=' + b.length);
    for (let i = 0; i < Math.min(a.length, b.length) && out.length < 4; i++) {
      if (stable(a[i]) !== stable(b[i])) {
        if (a[i] && b[i] && typeof a[i] === 'object') {
          const keys = new Set(Object.keys(a[i]).concat(Object.keys(b[i])));
          keys.forEach(k => { if (out.length < 4 && stable(a[i][k]) !== stable(b[i][k])) out.push('item ' + i + ' field ' + k + ': new=' + stable(a[i][k]).slice(0, 60) + ' old=' + stable(b[i][k]).slice(0, 60)); });
        } else out.push('item ' + i + ': new=' + stable(a[i]).slice(0, 60) + ' old=' + stable(b[i]).slice(0, 60));
      }
    }
  } else if (a && b && typeof a === 'object') {
    Object.keys(Object.assign({}, a, b)).forEach(k => { if (out.length < 4 && stable(a[k]) !== stable(b[k])) out.push('field ' + k); });
    if (a.data !== undefined && b.data !== undefined) return firstDiffs(a.data, b.data);
  }
  return out;
}

async function viaGas(fn, args) {
  const t0 = Date.now();
  const r = await fetch(process.env.GAS_URL, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ fn: fn, args: args || [] }) });
  const text = await r.text();
  let out; try { out = JSON.parse(text); } catch (e) { throw new Error('Apps Script returned a web page, not data'); }
  if (!out.ok) throw new Error(out.error);
  return { v: out.data, ms: Date.now() - t0 };
}

// Test cases: every function with no inputs, plus per-company ones for the first few companies.
async function buildCases(n) {
  const cases = [['getBranchSelections', [['CSE'], [], '', null]], ['getBranchNoOffers', [['CSE'], [], '', null]], ['getBranchRoster', [['CSE'], [], '', null]],
    ['getVolunteerLiveOverview', []], ['getDashboardData', []], ['getCompanyList', []], ['getBranchAndCollegeLists', []],
    ['getBranchViewFilters', []], ['getTopPackageStudents', []], ['getPlacementRate', []], ['getPackageAnalytics', []],
    ['getGlobalSelectionSummary', []], ['getAllStudentsMaster', []]];
  const dash = await ported.getDashboardData();
  const names = dash.data.map(c => c.Company_Name).filter(Boolean).slice(0, n);
  const rounds = toObjects((await google.getSheets(['Process_Tracking']))['Process_Tracking']);
  for (const co of names) {
    cases.push(['getRegisteredStudents', [co]]);
    cases.push(['getRoundCounts', [co]]);
    cases.push(['getCompanyDetails', [co]]);
    cases.push(['getCompanyQuickSummary', [co]]);
    cases.push(['getRoundVolunteerAssignments', [co]]);
    cases.push(['getRegisteredStudentDownloadFields', [co]]);
    cases.push(['getRegisteredStudentEditFields', [co]]);
    cases.push(['getRegistrationFormForCompany', [co]]);
    try {
      const safeName = String(co).trim().replace(/[\[\]\*\?\/\\:]/g, ' ').replace(/^'+/, '').replace(/\s+/g, ' ').trim().substring(0, 80) || 'Unnamed';
      const regVals = (await google.getSheets(['Reg__' + safeName]))['Reg__' + safeName];
      const ei = regVals && regVals[0] ? regVals[0].indexOf('Enrollment_No') : -1;
      if (ei !== -1 && regVals.length > 1) cases.push(['checkRegistrationEligibility', [co, String(regVals[1][ei])]]);   // someone already registered
      const mVals = (await google.getSheets(['Students_Master']))['Students_Master'];
      const mi = mVals && mVals[0] ? mVals[0].indexOf('Enrollment') : -1;
      if (mi !== -1 && mVals.length > 1) cases.push(['checkRegistrationEligibility', [co, String(mVals[1][mi])]]);           // a student from the master list
    } catch (e) { /* that company has no registration sheet yet */ }
    const firstRound = rounds.filter(r => String(r.Company_Name).trim() === String(co).trim())[0];
    if (firstRound) {
      cases.push(['getGDRollCallCounts', [co, firstRound.Round_Name]]);
      cases.push(['getGDRollCallState', [co, firstRound.Round_Name]]);
      cases.push(['getVolunteerRoundBoard', [co, firstRound.Round_Name, false, '']]);
    }
    const first = rounds.filter(r => String(r.Company_Name).trim() === String(co).trim())[0];
    if (first) cases.push(['getRoundStudents', [co, first.Round_Name]]);
  }
  try {
    const volVals = (await google.getSheets(['Round_Volunteers']))['Round_Volunteers'];
    if (volVals && volVals.length > 1) {
      const h = volVals[0], r = volVals[1];
      cases.push(['getVolunteerRoundBoard', [r[h.indexOf('Company_Name')], r[h.indexOf('Round_Name')], false, String(r[h.indexOf('Volunteer_Mobile')])]]);
      cases.push(['volunteerLogin', [String(r[h.indexOf('Volunteer_Mobile')])]]);
    }
  } catch (e) { /* no volunteer sheet yet */ }
  try {
    const attVals = (await google.getSheets(['Attendance_Sessions']))['Attendance_Sessions'];
    if (attVals && attVals.length > 1) {
      const h = attVals[0], r = attVals[attVals.length - 1];
      const sid = String(r[h.indexOf('Session_ID')]);
      cases.push(['getAttendanceSessionStatus', [sid]]);
      cases.push(['getCurrentAttendanceToken', [sid]]);
      cases.push(['verifyVolunteerMobile', [sid, '9876543210']]);
    }
  } catch (e) { /* no attendance sessions yet */ }
  try {
    const selVals = (await google.getSheets(['Selected_Students']))['Selected_Students'];
    if (selVals && selVals.length > 1) {
      const h = selVals[0], r = selVals[1];
      const co = String(r[h.indexOf('Company_Name')]), en = String(r[h.indexOf('Enrollment_No')]);
      cases.push(['getPhotoRequestForStudent', [co, en]]);
      cases.push(['getFeedbackFormForStudent', [co, en]]);
    }
  } catch (e) { /* no selected students yet */ }
  if (names.length) cases.push(['globalSearch', [String(names[0]).trim().slice(0, 3)]]);
  return cases;
}

const statusHandler = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const q = req.query || {};
  const report = {
    version: 'v19-branch-lists',
    GAS_URL_set: !!process.env.GAS_URL,
    SHEET_ID_set: !!process.env.SHEET_ID,
    GOOGLE_CREDENTIALS_set: !!process.env.GOOGLE_CREDENTIALS,
    FAST_EXTRA_now: process.env.FAST_EXTRA || '(empty)',
    ready: google.isConfigured()
  };
  if (!google.isConfigured()) report.next = 'Add SHEET_ID and GOOGLE_CREDENTIALS in Vercel > Settings > Environment Variables, then Redeploy.';
  else if (!process.env.GAS_URL) report.next = 'Add GAS_URL (your Apps Script /exec address) in Vercel > Settings > Environment Variables, then Redeploy.';

  if (q.compare === '1' && google.isConfigured() && process.env.GAS_URL) {
    const n = Math.max(1, Math.min(4, parseInt(q.n || '2', 10) || 2));
    let cases;
    try { cases = await buildCases(n); if (q.only) cases = cases.filter(c => c[0] === q.only); } catch (err) { report.error = String(err.message); return res.status(200).json(report); }
    const results = await Promise.all(cases.map(async ([fn, args]) => {
      const row = { fn: fn, args: args };
      try {
        const t0 = Date.now();
        const mine = await ported[fn].apply(null, args);
        row.new_ms = Date.now() - t0;
        const old = await viaGas(fn, args);
        row.old_ms = old.ms;
        // the seconds left in the QR window changes between the two calls; everything else must be identical
        const timeless = v => { if (fn !== 'getCurrentAttendanceToken' || !v) return v; const c = Object.assign({}, v); delete c.secondsRemaining; return c; };
        row.identical = stable(timeless(mine)) === stable(timeless(old.v));
        if (!row.identical) row.differences = firstDiffs(mine, old.v);
      } catch (err) { row.error = String(err.message); }
      return row;
    }));
    report.compare = results;
    const byFn = {};
    results.forEach(r => { byFn[r.fn] = (byFn[r.fn] === false) ? false : (r.identical === true); });
    const ok = Object.keys(byFn).filter(f => byFn[f]);
    const bad = Object.keys(byFn).filter(f => !byFn[f]);
    report.safe_to_enable = ok.join(',');
    report.NOT_identical = bad.join(',') || 'none';
    report.how_to_enable = q.only ? 'You tested only ' + q.only + '. Do NOT copy a list from this page. Run /api/status?compare=1&n=1 (without only) and use that, or set FAST_EXTRA to the single word  all  once every function says identical.' : 'In Vercel > Settings > Environment Variables set FAST_EXTRA = ' + (ok.filter(f => ['getBranchAndCollegeLists', 'getRegisteredStudents', 'getRoundStudents', 'getRoundCounts', 'getCompanyDetails', 'getBranchViewFilters', 'getTopPackageStudents', 'getPlacementRate', 'getPackageAnalytics', 'getGlobalSelectionSummary', 'getAllStudentsMaster', 'getRegisteredStudentDownloadFields', 'getRegisteredStudentEditFields', 'getGDRollCallCounts', 'getGDRollCallState', 'getVolunteerRoundBoard', 'volunteerLogin', 'syncVolunteerRoundOnOpen', 'getRegistrationFormForCompany', 'checkRegistrationEligibility', 'getAttendanceSessionStatus', 'verifyVolunteerMobile', 'getPhotoRequestForStudent', 'getFeedbackFormForStudent', 'getCurrentAttendanceToken', 'getVolunteerLiveOverview', 'getCompanyQuickSummary', 'globalSearch', 'getRoundVolunteerAssignments', 'getBranchSelections', 'getBranchNoOffers', 'getBranchRoster'].indexOf(f) !== -1).join(',') || '(nothing yet)') + ' then Redeploy.';
  }
  res.status(200).json(report);
};

// Never let this page crash: if anything goes wrong, say what it was instead of a blank error page.
module.exports = async (req, res) => {
  try { await statusHandler(req, res); }
  catch (err) {
    res.setHeader('Cache-Control', 'no-store');
    res.status(200).json({ version: 'v19-branch-lists', error: String((err && err.message) || err), where: String((err && err.stack) || '').split('\n').slice(0, 4) });
  }
};
